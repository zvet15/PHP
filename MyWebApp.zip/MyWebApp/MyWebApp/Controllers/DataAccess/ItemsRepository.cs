﻿using MyWebApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyWebApp.Controllers.DataAccess
{
    public class ItemsRepository : ConnectionClass
    {
        //will call the base constructor and it will inheriate from connection class, and anything connected to the connection class can call anything.
        public ItemsRepository() : base()
        { }

        //will get all items from the db.. I from IQueryable is Interface. 
        //IQueryable will open the connection once. if you use the .ToList will open the connection multiple times for sorting,orderby etc.
        public IQueryable<Item> GetItems()
        {
            return Entity.Items;
        }


        // delete update and insert ALWAYS SAVE BECAUSE OF THE DATABASE.
        public void AddItem(Item i)
        {
            i.Id = Guid.NewGuid();
            Entity.Items.Add(i);
            Entity.SaveChanges();
        }

        public void Delete(Item i)
        {
            Entity.Items.Remove(i);
            Entity.SaveChanges();
        }

        public void Update(Item edited)
        {
            Item original = GetItems().SingleOrDefault(x => x.Id == edited.Id);
            original.Name = edited.Name;
            original.CategoryFK = edited.CategoryFK;
            original.Price = edited.Price;
            original.Desription = edited.Desription;

            Entity.SaveChanges();
        }

        public void AddItemPhoto(Photo p)
        {
            Entity.Photos.Add(p);
            Entity.SaveChanges();
        }

        public IQueryable<Photo>GetPhotosForItem(Guid id)
        {
            return Entity.Photos.Where(x=>x.Item_Fk==id);

        }

        public Photo GetPhoto(int id)
        {
            return Entity.Photos.SingleOrDefault(x => x.Id == id);
        }
    }
}