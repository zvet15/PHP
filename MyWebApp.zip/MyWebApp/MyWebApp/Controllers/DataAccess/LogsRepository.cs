﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;

namespace MyWebApp.Controllers.DataAccess
{
    public class LogsRepository
    {
        public void LogError(string username, Exception ex, string page, string method)
        {

            if (ex.InnerException != null)
            {

                Trace.WriteLine(String.Format("Username : {0}, Exception: {1}, Message: {2}, Page: {3}, Method: {4}, Inner Exception: {5}, Date: {6}",
                    username, ex.GetType().ToString(), ex.Message, page, method, ex.InnerException.Message,DateTime.Now
                    )                    
                    );
            }
            else
            {
                    Trace.WriteLine(String.Format("Username : {0}, Exception: {1}, Message: {2}, Page: {3}, Method: {4},  Date: {5}",
                 username, ex.GetType().ToString(), ex.Message, page, method,  DateTime.Now
                 )
                 );
            }
        }

        public void LogError(string username, string message, string method)
        {
            Trace.WriteLine(String.Format("Username : {0}, Message: {1}, Method: {2}, Date: {3}",
                    username, message,method , DateTime.Now
                    )
                    );
        }
    }
}