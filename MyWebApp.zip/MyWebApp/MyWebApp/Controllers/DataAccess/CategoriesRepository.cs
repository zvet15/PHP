﻿using MyWebApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyWebApp.Controllers.DataAccess
{
    public class CategoriesRepository: ConnectionClass
    {
        //will call the base constructor and it will inheriate from connection class, and anything connected to the connection class can call anything.
        public CategoriesRepository():base()
        {
        }

        public IQueryable<Category> GetCategories()
        {
            return Entity.Categories;
        }



    }
}