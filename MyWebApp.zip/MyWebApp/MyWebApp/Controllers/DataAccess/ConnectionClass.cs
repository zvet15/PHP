﻿using MyWebApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyWebApp.Controllers.DataAccess
{
    public class ConnectionClass
    {

        /// <summary>
        ///  open the database connection and close the connection.
        /// </summary>
        public a100022dbEntities Entity { get; set; }

        public ConnectionClass()
        {
            Entity = new a100022dbEntities();
        }
    }
}