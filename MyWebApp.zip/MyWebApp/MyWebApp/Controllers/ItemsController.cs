﻿using MyWebApp.Controllers.DataAccess;
using MyWebApp.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MyWebApp.Controllers
{
    public class ItemsController : Controller
    {
        // GET: Items
        public ActionResult List()
        {
            //creating the instance will provide us to call the method from the IitemsRepository class
            ItemsRepository ir = new ItemsRepository();
            var list = ir.GetItems(); //calling the database

            return View(list);
        }
        [ValidateAntiForgeryToken]
        public ActionResult Search(string keyword)
        {
            ItemsRepository ir = new ItemsRepository();
            var filteredList = ir.GetItems().Where(item=>item.Name.Contains(keyword));//searching for a word in that iteam list

            return View("List",filteredList);

        }

        public ActionResult Details(Guid id) //guid is the datatype of a unique identifier
        {
            try
            {
                ItemsRepository ir = new ItemsRepository();
                var myItem = ir.GetItems().SingleOrDefault(x => x.Id == id);
                if(myItem==null)
                {
                    return RedirectToAction("List");

                }
                return View("Details", myItem);
            }
            catch
            {
                ViewBag.Message = "Error occured....";
                return RedirectToAction("List");
            }

        }
        [HttpGet] //when loading the pagfe will get the HTTPGET
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost] //when submiting the form will get the GETPOST
        [ValidateAntiForgeryToken]  //you will be vulnerable if you dont do it.
        public ActionResult Create(Item model)
        {
            /*try
            {
                if (model.Name == "")
                {
                    ModelState.AddModelError("Name","Input Name");
                }
                else
                {
                    ItemsRepository ir = new ItemsRepository();
                    ir.AddItem(model);
                    ViewBag.Message = "Item was added successfully";
                }
           
            }
            catch(Exception ex)
            {
                ViewBag.Error = "Item was not added";
            }
            */

            try
            {
                //throw new Exception("Error"); //  to create a textfile

                if (ModelState.IsValid)
                {
                    ItemsRepository ir = new ItemsRepository();
                    ir.AddItem(model);
                    ViewBag.Message = "Item was added successfully";
                    ModelState.Clear(); //to clear the textboxes
                }


            }
            catch (Exception ex)
            {
                string controllerName = this.ControllerContext.RouteData.Values["action"].ToString();
                string actionName = this.ControllerContext.RouteData.Values["controller"].ToString();
                //new LogsRepository().LogError(User.Identity.Name, ex, "Create", controllerName+"/"+actionName);

                ViewBag.Error = "Item was not added";
                new LogsRepository().LogError(User.Identity.Name,ex,"Create",controllerName+"//"+actionName);
            }
            return View();
        }

        public ActionResult Delete(Guid id)
        {
            ItemsRepository ir = new ItemsRepository();
            var myItem = ir.GetItems().SingleOrDefault(x=>x.Id==id); //instead of where 

            if(myItem != null)
            {
                ir.Delete(myItem);
                TempData["Message"] = "Item deleted successfully";
            }

            return RedirectToAction("List");
            
        }


        [HttpGet]
        public ActionResult Edit(Guid id)
        {


            ItemsRepository ir = new ItemsRepository();
            var myItem = ir.GetItems().SingleOrDefault(x => x.Id == id); //instead of where 

            return View(myItem);

        }

        [HttpPost][ValidateAntiForgeryToken]
        public ActionResult Edit(Item data)
        {

            if(ModelState.IsValid)
            {
                new ItemsRepository().Update(data);
                TempData["Message"] = "Updated Successfully";
            }
            else
            {
                ViewBag.Error = "Update failed";
                return View(data);
            }

            return RedirectToAction("List");

        }

        public ActionResult Upload(Guid id)
        {
            ItemsRepository ir = new ItemsRepository();
            var myItem = ir.GetItems().SingleOrDefault(x => x.Id == id);
            return View(myItem);
        }
        [HttpPost][ValidateAntiForgeryToken]
        //HttpPostedFileBase to upload a file
        public ActionResult Upload(Guid id, HttpPostedFileBase file)
        {
            //ALWAYS IN A TRY AND CATCH BECAUSE IF THE FILE FAILS NEED TO DISPLAY A MESSAGE.
            ItemsRepository ir = new ItemsRepository();
            string newFilename;
            string absolutePath="";
            try
            {
                //VALIDATION OF THE UPLOADED FILE
                //FF 255
                //D8 216

                byte[] bytesRead = new byte [2]; // 2 because your searching for dd and d8 
                                                 //for assignment zip file

                file.InputStream.Read(bytesRead, 0, 2); //kompli minn fejn hallejt 0, 2 kemm se taqra


                if (bytesRead[0]==255 && bytesRead[1]==216)
                {

                    file.InputStream.Position = 0; //biex jerga jibda mil bidumeta jibda jaqra
                    //you are saving the physcal file into a folder called Images

                    newFilename = Guid.NewGuid() + System.IO.Path.GetExtension(file.FileName); //generating a unique filename
                    absolutePath = Server.MapPath("\\Images") + "\\" + newFilename; //to get the full path where to save the file
                    file.SaveAs(absolutePath);

                    //saving the details of the uploaded file in the database
                    //ItemsRepository ir = new ItemsRepository();
                    Photo p = new Photo();
                    p.Path = "\\Images\\" + newFilename;   //storing the relative path
                    p.Item_Fk = id;
                    ir.AddItemPhoto(p);
                    ViewBag.Message = "File Uploaded";
                }
                else
                {
                    ViewBag.Error = "File is not allowed. Upload only .jpg files";
                }


            }
            catch(Exception ex)
            {
                if (System.IO.File.Exists(absolutePath))               
                    System.IO.File.Delete(absolutePath);
                ViewBag.Error = "File was not uploaded";
                //log

                new LogsRepository().LogError(User.Identity.Name, ex, "File upload", "Items Controller" + "/" + "upload");
            }
            var myItem = ir.GetItems().SingleOrDefault(x => x.Id == id); // to return the item
            return View(myItem);
        }

        public ActionResult Download(int id)
        {

     


            var photo = new ItemsRepository().GetPhoto(id);

            //to delete the photo from the details page
            //System.IO.File.Delete(Server.MapPath(photo.Path));
            
                
                
            FileStream fs = System.IO.File.OpenRead(Server.MapPath(photo.Path));
            MemoryStream ms = new MemoryStream();
            fs.CopyTo(ms);
            ms.Position = 0;
            //get the absolute path of the photo
            return File(Server.MapPath(photo.Path),System.Net.Mime.MediaTypeNames.Application.Octet,System.IO.Path.GetFileName(photo.Path)); 
        }
    }
}