﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MyWebApp.Models
{
    public class ItemValidation
    {
        [Required(AllowEmptyStrings =false,ErrorMessage ="Please input a name for the item")]
        [RegularExpression("^([A-Za-z ]){3,50}$", ErrorMessage ="Name must contains 2 letters at lest")] //3-50 character because the var in the db is 50
        public string Name { get; set; }
    

        [Range(1,100000,ErrorMessage ="Price must be between 1 and 100000")]
        public decimal Price { get; set; } 

        [Display(Name = "Category")]
        public System.Guid CategoryFK { get; set; }
    }



    [MetadataType(typeof(ItemValidation))]

    public partial class Item
    {

    }

}